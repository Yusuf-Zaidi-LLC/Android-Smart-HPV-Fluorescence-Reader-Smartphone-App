/** Automatically generated file. DO NOT MODIFY */
package com.example.smart_hpv_fluorescencereader;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}