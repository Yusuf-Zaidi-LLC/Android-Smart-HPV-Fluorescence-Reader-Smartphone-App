package com.example.smart_hpv_fluorescencereader;

import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.opencsv.CSVReader;

import android.support.v7.app.ActionBarActivity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;




public class GraphActivity extends ActionBarActivity
{

	SharedPreferences csvfilename1;
	public static String filename= "SharedString1";
	
	CSVReader getTestVals;
//	TextView Intensityalternatetext;
	TextView absolutetext;
	
//	GraphView graphhueorintens;

		
//	GridLabelRenderer grapRend;
//	StaticLabelsFormatter staticLabelsFormatter;
	
	
	
	BarChart barChart;
	ArrayList<BarEntry> barentryseries;
	ArrayList<String> BarEntryLabels;
	BarDataSet Bardataset;
	BarData BARDATA;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_graph);
		
		
		barChart = (BarChart) findViewById(R.id.chart);
		barentryseries = new ArrayList<>();
		BarEntryLabels = new ArrayList<String>();
		
		csvfilename1 = getSharedPreferences(filename,0);
		
//		Intensityalternatetext = (TextView) findViewById(R.id.Wellnumb);
		absolutetext = (TextView) findViewById(R.id.absolute);
/*		
		graphhueorintens = (GraphView) findViewById(R.id.graph);
		graphhueorintens.setBackgroundColor(Color.CYAN);
		graphhueorintens.setTitle("Well # vs. Hue");
		graphhueorintens.getViewport().setScalable(true);
		graphhueorintens.getViewport().setScrollable(true);		
		
		graphhueorintens.getViewport().setXAxisBoundsManual(true);

		
		grapRend= graphhueorintens.getGridLabelRenderer();
		grapRend.setHorizontalAxisTitle("Well #");
		grapRend.setVerticalAxisTitle("Hue");
		
		
		
		grapRend.setLabelFormatter(new DefaultLabelFormatter()
		{
			public String getFormattedValue(float value)
	        {
	            return String.valueOf((int)value);
	        }
	    });
*/		
	//	graphhueorintens.getViewport().setMinX(1);
	/*	
		staticLabelsFormatter = new StaticLabelsFormatter(graphhueorintens);
		staticLabelsFormatter.setHorizontalLabels(new String[] {1+"", 2+"", 3+"", 4+"", 5+"", 6+"", 7+"", 8+""});
		grapRend.setLabelFormatter(staticLabelsFormatter);
	*/
	}


	
	
	public void LoadTD(View v) throws IOException
	{
		
		BarGraphSeries<DataPoint> hpvgraphdata;
		hpvgraphdata = new BarGraphSeries<DataPoint>(new DataPoint[]{});
		hpvgraphdata.setSpacing(50);
		
		
		
		String givenfileName = csvfilename1.getString("csvfilenameVal", "10");
	//	String csvFilename = Environment.getExternalStorageDirectory().getAbsolutePath()+"/FinishedBART-xLAMP_Graphs/"+givenfileName+".csv";
		String csvFilename = givenfileName;
		
		
		getTestVals = new CSVReader(new FileReader(csvFilename));
		
		String[] row = getTestVals.readNext();
		List<String[]> alldata = getTestVals.readAll();

		ArrayList<String> absolutehueintens = new ArrayList<String>();
		ArrayList<String> hueintenssubtract = new ArrayList<String>();

		ArrayList<String> Wellnumb = new ArrayList<String>();
		
		StringBuilder absvallargetext = new StringBuilder("");
		StringBuilder absvallargetextalternate = new StringBuilder("");
		for(int x=0;x<alldata.size();x++)
		{
			Wellnumb.add(String.valueOf(alldata.get(x)[0]));

			absolutehueintens.add(String.valueOf(alldata.get(x)[1]));
			hueintenssubtract.add(String.valueOf(alldata.get(x)[2]));
			//
			absvallargetext.append((String.format("%.1f", Float.valueOf(alldata.get(x)[1])))+",    ");
			absvallargetextalternate.append((String.format("%.1f", Float.valueOf(alldata.get(x)[3])))+",    ");
			
			hpvgraphdata.appendData(new DataPoint(Integer.valueOf(Wellnumb.get(x)), Double.valueOf(absolutehueintens.get(x))), true, 999999);
			//hpvgraphdata.appendData("hi", Double.valueOf(absolutehueintens.get(x))), false, 999999);	
			
			barentryseries.add(new BarEntry(Float.valueOf(absolutehueintens.get(x)),x));
			BarEntryLabels.add(Wellnumb.get(x));
		}
//		Wellnumbtext.setText(Wellnumb.get(0)+" "+Wellnumb.get(1)+" "+Wellnumb.get(2));
//		Intensityalternatetext.setText(absvallargetextalternate);	
		absolutetext.setText(absvallargetext);
		//absolutetext.setText(absolutehueintens.get(0)+" "+absolutehueintens.get(1)+" "+absolutehueintens.get(2));
		

//		hpvgraphdata.appendData(new DataPoint(LogsecondCopy, secondWellTime), false, 999999);
		
		
/*		
		graphhueorintens.addSeries(hpvgraphdata);
//		graphhueorintens.getViewport().setMinX(Wellnumb.size());
        graphhueorintens.getViewport().setMinX(0);
		graphhueorintens.getViewport().setMaxX(10);

		NumberFormat nf = NumberFormat.getInstance();
		nf.setMinimumIntegerDigits(1);
		System.out.println("grapRend: "+grapRend.getNumHorizontalLabels());
		grapRend.setNumHorizontalLabels(6);
		grapRend.setLabelFormatter(new DefaultLabelFormatter(nf, nf));
*/		
/*
		graphhueorintens.getViewport().setXAxisBoundsManual(true);
        StaticLabelsFormatter staticLabelsFormatter = new StaticLabelsFormatter(graphhueorintens);
        staticLabelsFormatter.setHorizontalLabels(new String[] {"1", "2","3","4","5","6","7","8","9","10","11","12","13","14","15"});
        graphhueorintens.getGridLabelRenderer().setLabelFormatter(staticLabelsFormatter);
*/	    

		
		
		
		
		//MPChart Bar Chart Set
		YAxis yAxis = barChart.getAxisLeft();
		yAxis.setAxisMaxValue(360);
		yAxis.setLabelCount(9, false);
		
		System.out.println(barChart.getYChartMax()+"ANother one: "+yAxis.getAxisMaximum());
		Bardataset = new BarDataSet(barentryseries, "Well #");
//		Bardataset.setColors(ColorTemplate.rgb(("#FF5722")));
		Bardataset.setColor(Color.BLUE);
		BARDATA = new BarData(BarEntryLabels,Bardataset);
		barChart.setData(BARDATA);
		barChart.animateY(300);
		barChart.setVerticalScrollBarEnabled(true);
		barChart.setDescription(" ");
		barChart.setDescriptionPosition(800, 100);
		barChart.getAxisRight().setDrawGridLines(false);	
		barChart.getAxisRight().setEnabled(false);
		barChart.getXAxis().setDrawGridLines(false);
		barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

		
		
	}
				
}
