package com.example.smart_hpv_fluorescencereader;




//Vikram, need to find how to crop match between canvas and real image. Something with scaling is wrong and it must be fixed. CHeck this first. getCroppedBitmap()
//Then, run cropped image through intensity test and save to variable.




import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.hardware.Camera.Area;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class MainActivity extends ActionBarActivity implements Callback, OnTouchListener
{
	protected static final String TAG = null;
	Camera camera1;
	SurfaceView surfaceView;
	SurfaceHolder surfaceHolder;
	ImageView AmplifPhoto;

	
	
	
	SharedPreferences csvfilename1;
	public static String filename= "SharedString1";
	
	
	ArrayList<String[]> RGBIntensdata = new ArrayList<String[]>();

	
	
	//Hue or Intensity Choice, int 1 means R int 2 means intensity int 3 means G int 4 means B
	int hueorint = 2;
	float returnval = 0;
	float returnval2 = 0;
	
	TextView loadHPVImgName;
	//TextView HueCheck;
	
	
//	float ThresholdValue =0;

	CSVWriter HueorIntensVals;
	
	float xCentertoCval;
	float yCentertoCval;
	
	
	ArrayList<Float> IntensityValues1 = new ArrayList<Float>();
	ArrayList<Double> TimeXAxisVals1 = new ArrayList<>();
	ArrayList<Bitmap> allExposPics = new ArrayList<>();
		
	
	SurfaceView rectSurf;
	SurfaceHolder rectSurfHold;
	boolean previewing = false;
	private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
	Random random;
	Bitmap SampImgbitfromV=null;
	Bitmap ControlImgbitfromV=null;
	Bitmap SubtractedImage;
	
	Bitmap InitialExpos;
	Bitmap FollowingExpos;
	
	TextView ExposNumb;
	int exposcompenNumb;
	TextView CropRectX;
	TextView CropRectY;
	TextView CropRectX2;
	TextView CropRectY2;
//	TextView Threshold;
	
	float currentmaxIntens; 
	float timeofmaxIntens; 
	
	
//	Bitmap VidtoPicImg;
	Handler handler;
	Handler handler2;
	Runnable r;
	Runnable r2; 
	GraphView graph;
	GridLabelRenderer grapRend; 

	// If 1, it is Sample......If 2, it is Control.... If 3, it is Subtracted image
	int checkSamporCont = 0;

	FrameLayout frame1;

	int checkPix = 0;
	double intensGrXcount=0;
	RelativeLayout.LayoutParams paramsrel; 
	LineGraphSeries<DataPoint> series1_intensity;

	float checktoFin=0;
	
	
	
	double CropImgX = 1439.0;
	double CropImgY = 2559.0;
	

	CheckBox FocusFreeze;
	
	

	Button buttonStartCameraPreview; 
	Button buttonsamplePictake;
	Button stopCapture;
	Button setCropRectSize;
	
	long totalEpochTimerOneRun;
	
	long startofEpochTimer;
	long shutterCallEpochTime;
	long pictureCallEpochTime;
	long pictakenEpochTime;
	long finishaddingEpochTime;
	
	long onShutterAddedVal;
	
	int bluerectX = 0;
	int bluerectY = 0;
	
	int bluerectX2 = 0;	
	int bluerectY2 = 0;	
	RadioGroup XYbluerectRadG;
	RadioButton XY1Radio;
	RadioButton XY2Radio;
	
//	RadioGroup WellArrayLayout;
	RadioGroup HueorIntensSetting;
	
	int welllayoutNumb = 3;
	int wellrowNumb = 1;
	TextView numbRows;
	TextView numbColumns;
	int NCposi = 2;
	int PCposi = 4;

	
	int cropSTARTX;
	int cropSTARTY;
	
	int ScreenTouchReason = 0;
	Rect focusArea = new Rect();
	
	int exposCaptNumbofImagesFixed= 0;
	
	int Exposcompensation;
	
	double XtimeInterval;
	
	PowerManager pm;
	
	double actualCaptInterval;
	
	int waitingTimeindicator = 0;
	int restartingapplicationbutton = 0;
	
	int checkifbothXYpointsset=0;
	
	int maxnumbofdatapoints;
	
	RadioButton Red;
	RadioButton Intensity;
	RadioButton Green;
	RadioButton Blue;
	
	

	int pctouchcheck =0;
	int nctouchcheck =0;
	int pcwellcheck =0;
	int ncwellcheck =0;
	
//	TextView FinalHPVResult;
//	TextView OtherVirus;
	
	ArrayList<Float> circlePosX = new ArrayList<>();
	ArrayList<Float> circlePosY = new ArrayList<>();
	
	ArrayList<String> passedThresholdVals = new ArrayList<>();
	
	ArrayList<ImageView> allimageViewsCheck; 
	
	ArrayList<String> namesselectWells = new ArrayList<>(Arrays.asList("IC","59","66","68","HIV","39","45","51","52","56","58","16","18","31","33","35"));
	
	ArrayList<Integer> selectedWellsVals = new ArrayList<>(Arrays.asList(1,2,3,4,5,7,8,9,10,11,12,14,15,16,17,18));

	ArrayList<Drawable> allfilledDrawables;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		
		
		
		allfilledDrawables = new ArrayList<>(Arrays.asList(getResources().getDrawable(R.drawable.filled_bl)
															,getResources().getDrawable(R.drawable.filled_59)
															,getResources().getDrawable(R.drawable.filled_66)
															,getResources().getDrawable(R.drawable.filled_68)
															,getResources().getDrawable(R.drawable.filled_hiv)
															,getResources().getDrawable(R.drawable.filled_39)
															,getResources().getDrawable(R.drawable.filled_45)
															,getResources().getDrawable(R.drawable.filled_51)
															,getResources().getDrawable(R.drawable.filled_52)
															,getResources().getDrawable(R.drawable.filled_56)
															,getResources().getDrawable(R.drawable.filled_58)
															,getResources().getDrawable(R.drawable.filled_16)
															,getResources().getDrawable(R.drawable.filled_18)
															,getResources().getDrawable(R.drawable.filled_31)
															,getResources().getDrawable(R.drawable.filled_33)
															,getResources().getDrawable(R.drawable.filled_35)));		
		
		
		
		


		
		numbRows = (TextView) findViewById(R.id.Rows);
		numbColumns = (TextView) findViewById(R.id.Columns);
		
		loadHPVImgName = (TextView) findViewById(R.id.loadHPVImgName);
		
//Below Allows phone to sleep but continues to run the app
		pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		WakeLock mWakeLock = pm.newWakeLock(pm.PARTIAL_WAKE_LOCK,"Tag");		
		mWakeLock.acquire();
//^^		
		XYbluerectRadG = (RadioGroup) findViewById(R.id.radioXYchoose);
		
		XY1Radio = (RadioButton) findViewById(R.id.XY1Radio);
		XY2Radio = (RadioButton) findViewById(R.id.XY2Radio);
		
		
		
//		WellArrayLayout = (RadioGroup) findViewById(R.id.WellArrayLayout);
		HueorIntensSetting = (RadioGroup) findViewById(R.id.HueorIntensSetting);
		Red = (RadioButton) findViewById(R.id.Red);
		Intensity = (RadioButton) findViewById(R.id.Intensity);
		Green = (RadioButton) findViewById(R.id.Green);
		Blue = (RadioButton) findViewById(R.id.Blue);

		
		HueorIntensSetting.check(Red.getId());
		
		ExposNumb = (TextView) findViewById(R.id.exposNumb);

		CropRectX = (TextView) findViewById(R.id.CropRectX);
		CropRectY = (TextView) findViewById(R.id.CropRectY);

		CropRectX2 = (TextView) findViewById(R.id.CropRectX2);
		CropRectY2 = (TextView) findViewById(R.id.CropRectY2);
				
//		Threshold = (TextView) findViewById(R.id.thresholdnumb);
//		FinalHPVResult = (TextView) findViewById(R.id.textView2);
//		OtherVirus = (TextView) findViewById(R.id.textView35);
		
		AmplifPhoto = (ImageView) findViewById(R.id.amplifPhoto);
		frame1 = (FrameLayout) findViewById(R.id.frameLayout1);
		paramsrel = (RelativeLayout.LayoutParams) frame1.getLayoutParams();
		
	//	HueCheck = (TextView) findViewById(R.id.HueCheck);
//		paramsrel.height = 700;
		
		buttonStartCameraPreview = (Button) findViewById(R.id.startcamerapreview);
		buttonsamplePictake = (Button) findViewById(R.id.samplePictake);
		buttonsamplePictake.setEnabled(false);
//		Button buttoncontrolPictake = (Button) findViewById(R.id.controlPictake);
		stopCapture = (Button) findViewById(R.id.cancelTake);
		setCropRectSize = (Button) findViewById(R.id.SetCropViewSize);
		
		
		rectSurf = (SurfaceView) findViewById(R.id.drawRectSurf);
		rectSurf.setZOrderOnTop(true);
		rectSurfHold = rectSurf.getHolder();
		rectSurfHold.setFormat(PixelFormat.TRANSPARENT);
		
		getWindow().setFormat(PixelFormat.UNKNOWN);
		surfaceView = (SurfaceView) findViewById(R.id.surfaceview);
		surfaceHolder = surfaceView.getHolder();
		surfaceHolder.addCallback(this);
		surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		surfaceView.setOnTouchListener(this);
		
		csvfilename1 = getSharedPreferences(filename,0);		
		String csvfilenameString = csvfilename1.getString("csvfilenameVal", "10");
		
		
//		stopCapture.setEnabled(false);
//		setCropRectSize.setEnabled(false);

		
		ExposNumb.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after)
			{
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count)
			{
				// TODO Auto-generated method stub
				
			}

			@Override
			public void afterTextChanged(Editable s)
			{

					run();
				
			}
		});
		

		
		HueorIntensSetting.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
		    public void onCheckedChanged(RadioGroup group, int checkedId) 
		       {
					
					
					System.out.println("Button ID: "+Red.getId());
					System.out.println("RadioButton ID" + HueorIntensSetting.getCheckedRadioButtonId());
					if(HueorIntensSetting.getCheckedRadioButtonId()==Red.getId())
					{
						//Red
						hueorint = 1;
					}
					if(HueorIntensSetting.getCheckedRadioButtonId()==Intensity.getId())
					{
						hueorint = 2;

					}
					if(HueorIntensSetting.getCheckedRadioButtonId()==Green.getId())
					{
						hueorint = 3;

					}
					if(HueorIntensSetting.getCheckedRadioButtonId()==Blue.getId())
					{
						hueorint = 4;

					}
					
	
		       }});
		

		
	}
	
	
	
	
	
/*	
	public void csvplotdata() throws IOException
	{
		CSVReader reader = new CSVReader(new FileReader(Environment.getExternalStorageDirectory().getAbsolutePath()+"/FinishedBART-LAMP_Graphs/IntensityCSVData_01-30-16_10-02-00.csv"));
	    List myEntries = reader.readAll();
	    
	    for(int x=0;x<myEntries.size();x++)
	    {
		    String[] newstring = (String[]) myEntries.get(x);
		    series1_intensity.appendData(new DataPoint(Float.parseFloat(newstring[0]), Float.parseFloat(newstring[1])), false, 1000);
			graph.addSeries(series1_intensity);

	    }
		reader.close();
	}
*/	
	

	public void startcamerapreview(View view) throws IOException
	{
//		csvplotdata();
		buttonsamplePictake.setEnabled(true);

		if(restartingapplicationbutton==1)
		{

			camera1.stopPreview();
			camera1.release();
			finish();
			startActivity(getIntent());
			restartingapplicationbutton = 0;
		}
		
		
		
		else
		{
//			buttonStartCameraPreview.setEnabled(false);
			
			System.out.println("startcamerprev");
			
			System.out.println("FrameView Height is: "+String.valueOf(frame1.getHeight()));
			System.out.println("FrameView Width is: "+String.valueOf(frame1.getWidth()));
	//		Integer.parseInt(ExposNumb.getText().toString());
			
//			System.out.println("ExposNumb: "+(ExposNumb.getText().toString()));
					
	//		exposcompenNumb = (Integer.parseInt(ExposNumb.getText().toString()))*4;
			
			// TODO Auto-generated method stub
			if (!previewing)
			{
				camera1 = Camera.open();
				if (camera1 != null)
				{
					try
					{
						Camera.Parameters params = camera1.getParameters();
	
						camera1.setPreviewDisplay(surfaceHolder);
						camera1.setDisplayOrientation(90);
						camera1.startPreview();
						previewing = true;
						// set camera to continually auto-focus
	//					params.setFocusMode("continuous-picture");
	//					params.setPreviewSize(, );
	//					params.setExposureCompensation(exposcompenNumb);
	//					params.setExposureCompensation(3);
						params.setAntibanding("auto");
					
						
	//					System.out.println(params.isAutoExposureLockSupported());
						params.isAutoExposureLockSupported();
	//					params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
	                    System.out.println("ExposLock_Beginning: "+params.getAutoExposureLock());
	
	//			        params.setAutoExposureLock(false);
	//			        params.setAutoWhiteBalanceLock(false);
	//			        params.setExposureCompensation(params.getMaxExposureCompensation());
				        
						camera1.setParameters(params);
	//					run();
					} catch (IOException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void setCropWindSize(View view)
	{
		
		CropImgX = (Float.parseFloat(CropRectX2.getText().toString()))-(Float.parseFloat(CropRectX.getText().toString()));
		CropImgY = (Float.parseFloat(CropRectY2.getText().toString()))-(Float.parseFloat(CropRectY.getText().toString()));
		
		System.out.println("THE CROPIMGX is: "+CropImgX);
		System.out.println("THE CROPIMGY is: "+CropImgY);

		
		cropSTARTX = (Integer.parseInt((CropRectX.getText().toString())));
		cropSTARTY = (Integer.parseInt((CropRectY.getText().toString())));
		
		//Setting Well Array values, values if maxed out also set
		if(Integer.valueOf(numbColumns.getText().toString())>8)
		{
			welllayoutNumb = 8;
		}
		else
		{
			welllayoutNumb = Integer.valueOf(numbColumns.getText().toString());
		}
		
		if(Integer.valueOf(numbRows.getText().toString())>6)
		{
			wellrowNumb = 6;
		}
		else
		{
			wellrowNumb = Integer.valueOf(numbRows.getText().toString());
		}
		//Setting positions of NC and PC wells

	
		run();
	}
	public void setCropWindSize2()
	{
		CropImgX = (Float.parseFloat(CropRectX2.getText().toString()))-(Float.parseFloat(CropRectX.getText().toString()));
		CropImgY = (Float.parseFloat(CropRectY2.getText().toString()))-(Float.parseFloat(CropRectY.getText().toString()));
		
		System.out.println("THE CROPIMGX is: "+CropImgX);
		System.out.println("THE CROPIMGY is: "+CropImgY);

		
		cropSTARTX = (Integer.parseInt((CropRectX.getText().toString())));
		cropSTARTY = (Integer.parseInt((CropRectY.getText().toString())));
		
		//Setting Well Array values, values if maxed out also set
		if(Integer.valueOf(numbColumns.getText().toString())>8)
		{
			welllayoutNumb = 8;
		}
		else
		{
			welllayoutNumb = Integer.valueOf(numbColumns.getText().toString());
		}
		
		if(Integer.valueOf(numbRows.getText().toString())>6)
		{
			wellrowNumb = 6;
		}
		else
		{
			wellrowNumb = Integer.valueOf(numbRows.getText().toString());
		}
		//Setting positions of NC and PC wells

		run();
	}
	
	
	
	
	public void samplePictake(View view) throws InterruptedException, IOException
	{
		
//		buttonsamplePictake.setEnabled(false);
		stopCapture.setEnabled(true);
		System.out.println("samplepictake");
		checkSamporCont = 1;
		
		ScreenTouchReason = 1;
				
		
		Thread.sleep(500);
		
		/*
		 * The below allows the camera to take photos every x seconds (set in milliseconds) and will save the image.
		 */
		camera1.enableShutterSound(true);				
	    	
		camera1.takePicture(myShutterCallback,null,myPictureCallback_JPG);			

  	
	}
	

	
	
	public void loadData(View view)
	{
		String loadImgName = loadHPVImgName.getText().toString();
		File imgFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() +"/HPVLoadImg/" + loadImgName+ ".jpg");
//		AmplifPhoto.setImageAlpha(0);
		if(imgFile.exists())
		{
			Bitmap ImgBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
			AmplifPhoto.setImageBitmap(ImgBitmap);
			InitialExpos = ImgBitmap;
			checkSamporCont=1;
		//	savePic(InitialExpos);
		}
		
		ScreenTouchReason = 1;
	}
	

	
	public void cancelTake(View view)
	{
		System.out.println("cancel");
		handler.removeCallbacks(r);
		handler2.removeCallbacks(r2);
		restartingapplicationbutton=1;
		buttonStartCameraPreview.setEnabled(true);
				

	}

	
	

    
	
	public float getIntensity(Bitmap pictogetIntens)
	{	

		
		Bitmap bmSampOrig = pictogetIntens;
		
		// TODO Auto-generated method stub
/*
		ArrayList<Integer> newImgR = new ArrayList<Integer>();
		ArrayList<Integer> newImgG = new ArrayList<Integer>();
		ArrayList<Integer> newImgB = new ArrayList<Integer>();
		ArrayList<Integer> totRGBIntensity = new ArrayList<Integer>();
*/		
		int origWidth = bmSampOrig.getWidth();
		int origHeight = bmSampOrig.getHeight();
		
		int RGBIntensAdder = 0;
		int pixelcounter = 0;
		
		int totRed = 0;
		int totBlue = 0;
		int totGreen = 0;

		
		for(int x = 0; x<origWidth; x++)
		{
			for(int y = 0; y<origHeight; y++)
			{
//				int alphapicRes = Color.alpha(bmSampOrig.getPixel(x, y))-Color.alpha(bmSampBackg.getPixel(x, y));			
				int redpicRes = Color.red(bmSampOrig.getPixel(x, y));			
				int greenpicRes = Color.green(bmSampOrig.getPixel(x, y));
				int bluepicRes = Color.blue(bmSampOrig.getPixel(x, y));

				totRed+=redpicRes;
				totBlue+=bluepicRes;
				totGreen+=greenpicRes;
				
				pixelcounter+=1;
				

				//To take away black pixels
//				if(redpicRes==0 && greenpicRes==0 && bluepicRes==0)
//				{
//					pixelcounter-=1;
//				}
				
				int totRGBinstance = redpicRes+greenpicRes+bluepicRes;
				
				
				
				RGBIntensAdder += totRGBinstance;

			}
			
		}

		System.out.println("RED: "+totRed);
		System.out.println("BLUE: "+totBlue);
		System.out.println("GREEN: "+totGreen);
		
		
		
		
		returnval = 0;
		returnval2 = 0;
		if (hueorint == 1)
		{
		//	float[] hsv = new float[3];
		//	Color.RGBToHSV(totRed, totGreen, totBlue, hsv);
		//	HueCheck.setText("Total Intensity:"+ RGBIntensAdder);
			System.out.println("Red:"+ totRed);
			returnval = totRed;
			
			float totalRGBIntensity = RGBIntensAdder/pixelcounter;
			float totalRIntensity = totRed/pixelcounter;
			float totalGIntensity = totGreen/pixelcounter;
			float totalBIntensity = totBlue/pixelcounter;
			RGBIntensdata.add(new String[] {String.valueOf(totalRIntensity),String.valueOf(totalGIntensity),String.valueOf(totalBIntensity)});

			System.out.println("TotalIntenstiy: "+pixelcounter);
			if(RGBIntensAdder>=9000000) RGBIntensAdder=0;
			returnval2 = RGBIntensAdder;
		}
		else if(hueorint == 2)
		{
			float totalRGBIntensity = RGBIntensAdder/pixelcounter;
			float totalRIntensity = totRed/pixelcounter;
			float totalGIntensity = totGreen/pixelcounter;
			float totalBIntensity = totBlue/pixelcounter;
			
			System.out.println("TotalIntenstiy: "+pixelcounter);
			if(RGBIntensAdder>=9000000) RGBIntensAdder=0;
			returnval = RGBIntensAdder;	
			
			RGBIntensdata.add(new String[] {String.valueOf(totalRIntensity),String.valueOf(totalGIntensity),String.valueOf(totalBIntensity)});
			
			float[] hsv = new float[3];
			Color.RGBToHSV(totRed, totGreen, totBlue, hsv);
		//	HueCheck.setText("Total Intensity:"+ RGBIntensAdder);
			System.out.println("Hue:"+ hsv[0]);
			returnval2 = hsv[0];
		}
		else if (hueorint == 3)
		{

			System.out.println("Green:"+ totGreen);
			returnval = totGreen;
			
			float totalRGBIntensity = RGBIntensAdder/pixelcounter;
			float totalRIntensity = totRed/pixelcounter;
			float totalGIntensity = totGreen/pixelcounter;
			float totalBIntensity = totBlue/pixelcounter;
			RGBIntensdata.add(new String[] {String.valueOf(totalRIntensity),String.valueOf(totalGIntensity),String.valueOf(totalBIntensity)});

			System.out.println("TotalIntenstiy: "+pixelcounter);
			if(RGBIntensAdder>=9000000) RGBIntensAdder=0;
			returnval2 = RGBIntensAdder;
		}
		else if (hueorint == 4)
		{

			System.out.println("Blue:"+ totBlue);
			returnval = totBlue;
			
			float totalRGBIntensity = RGBIntensAdder/pixelcounter;
			float totalRIntensity = totRed/pixelcounter;
			float totalGIntensity = totGreen/pixelcounter;
			float totalBIntensity = totBlue/pixelcounter;
			RGBIntensdata.add(new String[] {String.valueOf(totalRIntensity),String.valueOf(totalGIntensity),String.valueOf(totalBIntensity)});

			System.out.println("TotalIntenstiy: "+pixelcounter);
			if(RGBIntensAdder>=9000000) RGBIntensAdder=0;
			returnval2 = RGBIntensAdder;
		}
		
		System.out.println("Final RETURN VAL: "+returnval);
		return returnval;
		
	}
	
	
	
	
	
	

	public void savePic(Bitmap bitfromV)
	{
		// Save the bitmap photo file to a directory on SD card
		String FolderNam = "";
		String FileNam = "";

		if (checkSamporCont == 1)
		{
			FolderNam = "/HPV_GenotyperImages";
			FileNam = "HPVGeno_Image";			
		}

		
		
		// later change below to be saved on device itself
		String file_path = Environment.getExternalStorageDirectory()
				.getAbsolutePath() + FolderNam;

		// Get current time and date in specified format and set to a string
		Calendar c = Calendar.getInstance();
		SimpleDateFormat df = new SimpleDateFormat("MM-dd-yy_hh-mm-ss");
		String curTimDat = df.format(c.getTime());

		// create or set to directory
		File directory = new File(file_path);
		if (directory.exists() == false)
		{
			directory.mkdirs();
		}

		// Now create Image file
		File imgFile = new File(directory, FileNam + curTimDat + ".jpg");
		// Tries to save the image
		try
		{
			FileOutputStream fOut = new FileOutputStream(imgFile);
			// photo.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
			bitfromV.compress(Bitmap.CompressFormat.JPEG, 85, fOut);

			fOut.flush();
			fOut.close();
					
			
			MediaScannerConnection.scanFile(this, new String[]
			{ imgFile.toString() }, null,
					new MediaScannerConnection.OnScanCompletedListener()
					{
						@Override
						public void onScanCompleted(String path, Uri uri)
						{
							Log.e("ExternalStorage", "Scanned" + path + ":");
							Log.e("ExternalStorage", " uri=" + uri);

						}
					});

			Toast toast = Toast.makeText(this, "Image Saved",
					Toast.LENGTH_SHORT);
			toast.show();
			
		}

		// In the case of crash
		catch (FileNotFoundException e)
		{
			Toast toast = Toast.makeText(this, "File not found",
					Toast.LENGTH_SHORT);
			toast.show();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			Toast toast = Toast.makeText(this, "File unable to be saved",
					Toast.LENGTH_SHORT);
			toast.show();

		}

	}



	public void clearandputImg()
	{
		rectSurf.setZOrderOnTop(true);
		// TODO Auto-generated method stub
		int gg = 1;
		while (gg == 1)
		{
			if (rectSurfHold.getSurface().isValid())
			{
				Canvas canvas = rectSurfHold.lockCanvas();
				// ... actual drawing on canvas
				
				canvas.drawColor(0, Mode.CLEAR);				
				paint.setStyle(Paint.Style.STROKE);
				paint.setStrokeWidth(5);

				paint.setColor(Color.GREEN);

				
				rectSurfHold.unlockCanvasAndPost(canvas);
				gg = 0;
	
			}
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
	
	public void drawPoint()
	{
		rectSurf.setZOrderOnTop(true);
		// TODO Auto-generated method stub
		int gg = 1;
		while (gg == 1)
		{
			if (rectSurfHold.getSurface().isValid())
			{
				Canvas canvas = rectSurfHold.lockCanvas();
				// ... actual drawing on canvas
				
				canvas.drawColor(0, Mode.CLEAR);				
				paint.setStyle(Paint.Style.STROKE);
				paint.setStrokeWidth(5);

				paint.setColor(Color.GREEN);
/*				
				int screenWidth = getResources().getDisplayMetrics().widthPixels;
				int screenHeight = getResources().getDisplayMetrics().heightPixels;				
				float screentosurfvRatioX = ((float)surfaceView.getWidth()/(float)screenWidth);
				float screentosurfvRatioY = ((float)screenHeight/surfaceView.getHeight());
				
				System.out.println("surfaceView.getWidth(): "+ surfaceView.getWidth());
				System.out.println("screenWidth: "+ screenWidth);
				System.out.println("CANVASWIDTH: "+canvas.getWidth());
				System.out.println("screentosurfvRatioX: "+screentosurfvRatioX);
*/
				
				
				canvas.drawCircle(bluerectX, bluerectY, 7, paint);	
				
				paint.setColor(Color.RED);
				
				canvas.drawCircle(bluerectX2, bluerectY2, 7, paint);
				
				rectSurfHold.unlockCanvasAndPost(canvas);
				gg = 0;
				
				if(checkifbothXYpointsset==2)
				{
					setCropRectSize.setEnabled(true);
				}
			}
		}
		setCropWindSize2();

	}
	

	public void run()
	{
		rectSurf.setZOrderOnTop(true);
		// TODO Auto-generated method stub
		int gg = 1;
		ScreenTouchReason = 1;
//		double SelectionWindX = (CropImgX/(1440.0/(frame1.getWidth())));
		double SelectionWindX = (CropImgX/(1440.0/(frame1.getWidth())));
		double SelectionWindY = (CropImgY/(2560.0/(frame1.getHeight())));	
		
		int SWindowXINT = (int) Math.floor(SelectionWindX);
		int SWindowYINT = (int) Math.floor(SelectionWindY);
		
	//	System.out.println("X: "+SWindowXINT+" Y: "+SWindowYINT);
		
		while (gg == 1)
		{
			if (rectSurfHold.getSurface().isValid())
			{
				Canvas canvas = rectSurfHold.lockCanvas();
				// ... actual drawing on canvas
				
				canvas.drawColor(0, Mode.CLEAR);
				paint.setStyle(Paint.Style.STROKE);
				paint.setStrokeWidth(3);

				int w = canvas.getWidth();
				int h = canvas.getHeight();
				int x = 100;
				int y = 100;
				int r = 110;
				int g = 143;
				int b = 231;
				
				paint.setColor(0xff000000 + (r << 16) + (g << 8) + b);
		//		canvas.drawRect(100, 50, 900, 450, paint);
		//		canvas.drawRect(100, 100, 500, 500, paint);
//				canvas.drawRect((Float.parseFloat(CropRectX.getText().toString())), (Float.parseFloat(CropRectY.getText().toString())), (Float.parseFloat(CropRectX2.getText().toString())), (Float.parseFloat(CropRectY2.getText().toString())), paint);				
				
				

	//			focusArea.set((Integer.parseInt(CropRectX.getText().toString())), (Integer.parseInt(CropRectY.getText().toString())), (Integer.parseInt(CropRectX2.getText().toString())), (Integer.parseInt(CropRectY2.getText().toString())));

				
				paint.setColor(Color.BLUE);
				paint.setTextSize(72);
				
				if(welllayoutNumb<=1)
				{
					xCentertoCval =  ((Float.parseFloat(CropRectX2.getText().toString()))-(Float.parseFloat(CropRectX.getText().toString())))/(welllayoutNumb);
				}
				else
				{
					xCentertoCval =  ((Float.parseFloat(CropRectX2.getText().toString()))-(Float.parseFloat(CropRectX.getText().toString())))/(welllayoutNumb-1);
				}
				
				if(wellrowNumb<=1)
				{
					yCentertoCval =  ((Float.parseFloat(CropRectY2.getText().toString()))-(Float.parseFloat(CropRectY.getText().toString())))/(wellrowNumb);

				}
				else
				{
					yCentertoCval =  ((Float.parseFloat(CropRectY2.getText().toString()))-(Float.parseFloat(CropRectY.getText().toString())))/(wellrowNumb-1);

				}
				
				
				int screenWidth = getResources().getDisplayMetrics().widthPixels;
				int screenHeight = getResources().getDisplayMetrics().heightPixels;
				float screentosurfvRatioX = ((float)screenWidth/(float)surfaceView.getWidth());
				float screentosurfvRatioY = ((float)screenHeight/(float)surfaceView.getHeight());
				
				float xCentertoCvalScaled;
				float yCentertoCvalScaled;
				
				if(welllayoutNumb<=1)
				{
					xCentertoCvalScaled =  ((Float.parseFloat(CropRectX2.getText().toString())*screentosurfvRatioX)-(Float.parseFloat(CropRectX.getText().toString())*screentosurfvRatioX))/(welllayoutNumb);
				}
				else
				{
					xCentertoCvalScaled =  ((Float.parseFloat(CropRectX2.getText().toString())*screentosurfvRatioX)-(Float.parseFloat(CropRectX.getText().toString())*screentosurfvRatioX))/(welllayoutNumb-1);
				}
				
				if(wellrowNumb<=1)
				{
					yCentertoCvalScaled =  ((Float.parseFloat(CropRectY2.getText().toString())*screentosurfvRatioY)-(Float.parseFloat(CropRectY.getText().toString())*screentosurfvRatioY))/(wellrowNumb);
				}
				else
				{
					yCentertoCvalScaled =  ((Float.parseFloat(CropRectY2.getText().toString())*screentosurfvRatioY)-(Float.parseFloat(CropRectY.getText().toString())*screentosurfvRatioY))/(wellrowNumb-1);
				}
				
				
				circlePosX.clear();
				circlePosY.clear();

				paint.setColor(Color.GREEN);
				for(int xx = 0;xx<welllayoutNumb;xx++)
				{
					
					for(int yy= 0;yy<wellrowNumb;yy++)
					{
						canvas.drawCircle((Float.parseFloat(CropRectX.getText().toString()))+(xCentertoCval*xx), (Float.parseFloat(CropRectY.getText().toString()))+(yCentertoCval*yy), Integer.parseInt(ExposNumb.getText().toString()), paint);
						
		//				System.out.println("ImageView Params W: "+((Float.parseFloat(CropRectX.getText().toString()))+(xCentertoCval*xx))+"   H: "+((Float.parseFloat(CropRectY.getText().toString()))+(yCentertoCval*yy)));

						circlePosX.add((Float.parseFloat(CropRectX.getText().toString())*screentosurfvRatioX)+(xCentertoCvalScaled*xx));
						circlePosY.add((Float.parseFloat(CropRectY.getText().toString())*screentosurfvRatioY)+(yCentertoCvalScaled*yy));
						
		//				System.out.println("Full Scale Pic Params W: "+((Float.parseFloat(CropRectX.getText().toString())*screentosurfvRatioX)+(xCentertoCvalScaled*xx))+"   H: "+((Float.parseFloat(CropRectY.getText().toString())*screentosurfvRatioY)+(yCentertoCvalScaled*yy)));
						paint.setColor(Color.BLUE);
					}
				}
				


				
/*
				for(int xx = 3;xx<4;xx++)
				{
					
					for(int yy= 6;yy<7;yy++)
					{
						canvas.drawCircle(50*(2*xx), (Float.parseFloat(CropRectY.getText().toString()))+(yCentertoCval*yy), 50, paint);
						
						System.out.println("ImageView Params W: "+(50*(2*xx))+"   H: "+((Float.parseFloat(CropRectY.getText().toString()))+(yCentertoCval*yy)));

						circlePosX.add(50*(2*xx)*(screentosurfvRatioX));
						circlePosY.add((Float.parseFloat(CropRectY.getText().toString())*screentosurfvRatioY)+(yCentertoCvalScaled*yy));
						
						System.out.println("Full Scale Pic Params W: "+(50*(2*xx)*(screentosurfvRatioX))+"   H: "+((Float.parseFloat(CropRectY.getText().toString())*screentosurfvRatioY)+(yCentertoCvalScaled*yy)));
			
					}
				}
*/				

/*				
				for(int xx = 2;xx<3;xx++)
				{
					
					for(int yy= 4;yy<5;yy++)
					{
						canvas.drawCircle((Float.parseFloat(CropRectX.getText().toString()))+(xCentertoCval*xx), 50*(2*yy), 50, paint);
						
						System.out.println("ImageView Params W: "+((Float.parseFloat(CropRectX.getText().toString()))+(xCentertoCval*xx)+"   H: "+50*(2*yy)));

						double textboxVal = (Double.parseDouble(CropRectX.getText().toString()));
						float textboxVal2 = (screentosurfvRatioX);
						float textboxVal3 = (xCentertoCvalScaled*xx);
						float textboxVal4 = (float)(Float.parseFloat(CropRectX2.getText().toString()));
						float textboxVal5 = screentosurfvRatioX;
						
						float textboxVal6 = (Float.parseFloat(CropRectX.getText().toString())*screentosurfvRatioX);
						
						
						double xxx = textboxVal;//(screentosurfvRatioX)+(xCentertoCvalScaled*xx);
						System.out.println("xxx: "+xxx);
						double yyy = 901.4085;
						
						
						circlePosX.add((float) xxx);
						circlePosY.add((float) yyy);
						
						System.out.println("Full Scale Pic Params W: "+((Float.parseFloat(CropRectX.getText().toString())*screentosurfvRatioX)+(xCentertoCvalScaled*xx))+"   H: "+(50*(2*yy)*(screentosurfvRatioY)));
			
					}
				}
		*/
				rectSurfHold.unlockCanvasAndPost(canvas);
				gg = 0;
			}
		}
	}

	
	public Bitmap getCroppedBitmap(Bitmap bitmap, float CPX, float CPY)
	{
	
		int screenWidth = getResources().getDisplayMetrics().widthPixels;
		int screenHeight = getResources().getDisplayMetrics().heightPixels;

	    //Works only when using preview capture
//		float screentosurfvRatioX = ((float)screenWidth/surfaceView.getWidth());
//		float screentosurfvRatioY = ((float)screenHeight/surfaceView.getHeight());
		
		float screentosurfvRatioX = ((float)bitmap.getWidth()/surfaceView.getWidth());
		float screentosurfvRatioY = ((float)bitmap.getHeight()/surfaceView.getHeight());

		System.out.println("bitmap.getWidth():  "+bitmap.getWidth());
		System.out.println("bitmap.getHeight():  "+bitmap.getHeight());
		
		
		
//		Bitmap output1 = Bitmap.createBitmap(bitmap, (int)(CPX*screentosurfvRatioX), (int)(CPY*screentosurfvRatioY), 25, 25);
//	    savePic(output1);

		
		
	    Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
	            bitmap.getHeight(), Config.ARGB_8888);
	    Canvas canvas = new Canvas(output);


  
	    final int color = 0xff424242;
	    final Paint paint = new Paint();
	    final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

	    paint.setAntiAlias(true);
	    canvas.drawARGB(0, 0, 0, 0);
	    paint.setColor(color);
	    
//		canvas.drawCircle((CPX*screentosurfvRatioX), (CPY*screentosurfvRatioY), Integer.parseInt(ExposNumb.getText().toString())*screentosurfvRatioX, paint);
	    canvas.drawCircle((CPX), (CPY), Integer.parseInt(ExposNumb.getText().toString())*(screentosurfvRatioY+screentosurfvRatioX)/2, paint);		
	    
	
	    paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
	    canvas.drawBitmap(bitmap, rect, rect, paint);
	    
	    
	//    savePic(output);
	    System.out.print("SAVED !!!!");
	    return output;
	    

		
	}
	
/*
	public void processMWPics(View v)
	{
		float SampleintensityvalNC = getIntensity(getCroppedBitmap(InitialExpos, circlePosX.get(0), circlePosY.get(0)));

	}
	

*/	
	
	
	
	
	
	
	public void testTake(View view)
	{
//		AmplifPhoto.setImageResource(android.R.color.transparent);
//		savePic(InitialExpos);
//		getCroppedBitmap(InitialExpos, circlePosX.get(5), circlePosY.get(5));
		
//		int screenWidth = getResources().getDisplayMetrics().widthPixels;
//		int screenHeight = getResources().getDisplayMetrics().heightPixels;
		
//		System.out.println("circlePosX.get(5): "+circlePosX.get(5));
//		System.out.println("NEWNUMB: "+circlePosX.get(5)*((float)InitialExpos.getWidth()/(float)screenWidth));
		
		
//		getCroppedBitmap(InitialExpos,circlePosX.get(5)*((float)InitialExpos.getWidth()/(float)screenWidth), circlePosY.get(5)*((float)InitialExpos.getHeight()/(float)screenHeight));
		
		startActivity(new Intent("com.example.smart_hpv_fluorescencereader.GRAPH"));
	}
	
	
	
	public void processMWPics(View v) throws IOException
	{
		
		Calendar c = Calendar.getInstance();
		SimpleDateFormat df = new SimpleDateFormat("MM-dd-yy_hh-mm-ss");
		String curTimDat = df.format(c.getTime());
		
		
		String csv = Environment.getExternalStorageDirectory().getAbsolutePath()+"/HPV_GenotyperImages/"+"CSVData_"+curTimDat+".csv";
		
		//SharedPreferences code
		SharedPreferences.Editor editor = csvfilename1.edit();
		editor.putString("csvfilenameVal", csv);
		editor.commit();
		
		
		HueorIntensVals = new CSVWriter(new FileWriter(csv));
		List<String[]> allcalibdata = new ArrayList<String[]>();
		
		if (hueorint == 1)
		{
			allcalibdata.add(new String[] {"Well #","Red", "Red (NC subtracted)", "Intensity"});
		}
		else if (hueorint == 2)
		{
			allcalibdata.add(new String[] {"Well #","Intensity", "Intensity (NC subtracted)", "Absolute Hue"});
			System.out.println("Entered Here");
		}
		else if (hueorint == 3)
		{
			allcalibdata.add(new String[] {"Well #","Green", "Green (NC subtracted)", "Intensity"});
		}
		else if (hueorint == 4)
		{
			allcalibdata.add(new String[] {"Well #","Blue", "Blue (NC subtracted)", "Intensity"});
		}
		
		int screenWidth = getResources().getDisplayMetrics().widthPixels;
		int screenHeight = getResources().getDisplayMetrics().heightPixels;
//		OtherVirus.setText("Other Virus: \n");
//		FinalHPVResult.setText("HPV Genotypes: \n");
		
		AmplifPhoto.setImageResource(android.R.color.transparent);
//		savePic(InitialExpos);
//		float SampleintensityvalNC = getIntensity(getCroppedBitmap(InitialExpos, circlePosX.get(5), circlePosY.get(5)));
		Bitmap sampNCBitmap = getCroppedBitmap(InitialExpos,circlePosX.get(NCposi-1)*((float)InitialExpos.getWidth()/(float)screenWidth), circlePosY.get(NCposi-1)*((float)InitialExpos.getHeight()/(float)screenHeight));
		float SampleintensityvalNC = getIntensity(sampNCBitmap);
		float alternateSampleintensityvalNC = returnval2;
		
		System.out.println("Intens: "+SampleintensityvalNC);

		
//		float SampleintensityvalPC = getIntensity(getCroppedBitmap(InitialExpos, circlePosX.get(12), circlePosY.get(12)));
		float SampleintensityvalPC = getIntensity(getCroppedBitmap(InitialExpos,circlePosX.get(PCposi-1)*((float)InitialExpos.getWidth()/(float)screenWidth), circlePosY.get(PCposi-1)*((float)InitialExpos.getHeight()/(float)screenHeight)));		
		float alternateSampleintensityvalPC = returnval2;
		
		
		int aaa = 0;
		
		while(welllayoutNumb*wellrowNumb>aaa)
		{
			int CurselectedVal = aaa+1;
			
			System.out.println("hueorint: "+hueorint);
			
//			float Sampleintensityval = getIntensity(getCroppedBitmap(InitialExpos, circlePosX.get((CurselectedVal-1)), circlePosY.get((CurselectedVal-1))));
			
			Bitmap sampleBitmap = getCroppedBitmap(InitialExpos,circlePosX.get((CurselectedVal-1))*((float)InitialExpos.getWidth()/(float)screenWidth), circlePosY.get((CurselectedVal-1))*((float)InitialExpos.getHeight()/(float)screenHeight));

			float Sampleintensityval = getIntensity(sampleBitmap);
			float alternateSampleintensityval = returnval2;
			
			//This is the intensity/hue of each test well minus the NC test well
			
			float SampintensminusNCval = 0;
			if (hueorint == 1)
			{
				//SampintensminusNCval = getHueSubtract(sampleBitmap, sampNCBitmap);
				SampintensminusNCval = Sampleintensityval - SampleintensityvalNC;
							}
			else if (hueorint == 2)
			{
				SampintensminusNCval = Sampleintensityval - SampleintensityvalNC;
				
			}
			
			
			
			allcalibdata.add(new String[] {String.valueOf(aaa+1),String.valueOf(Sampleintensityval), String.valueOf(SampintensminusNCval), String.valueOf(alternateSampleintensityval)});	
			
			//thresholdProcess(SampleintensityvalNC,SampleintensityvalPC, Sampleintensityval, aaa);

			aaa+=1;
		}
		HueorIntensVals.writeAll(allcalibdata);
		HueorIntensVals.flush();
		HueorIntensVals.close();

		
	}
	
	
	
	
	
	


	
	
	
	
	
	
	
	
	ShutterCallback myShutterCallback = new ShutterCallback()
	{

		public void onShutter()
		{	    	
			camera1.getParameters().setAutoExposureLock(true);
			camera1.getParameters().setAutoWhiteBalanceLock(true);

		}
	};

	PictureCallback myPictureCallback_RAW = new PictureCallback()
	{

		public void onPictureTaken(byte[] arg0, Camera arg1)
		{
			// TODO Auto-generated method stub
		}
	};

	
	
	
	PictureCallback myPictureCallback_JPG = new PictureCallback()
	{

		public void onPictureTaken(byte[] data, Camera arg1)
		{

            AmplifPhoto.setImageAlpha(0);
	    	
			int CrImgXINT = (int) Math.floor(CropImgX);
			int CrImgYINT = (int) Math.floor(CropImgY);
	    	
			
			int screenWidth;
			int screenHeight;
			
			if (data != null)
			{
				screenWidth = getResources().getDisplayMetrics().widthPixels;
				screenHeight = getResources().getDisplayMetrics().heightPixels;
				Bitmap bm = BitmapFactory.decodeByteArray(data, 0,
						(data != null) ? data.length : 0);

				if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
				{
					Bitmap scaled = Bitmap.createScaledBitmap(bm, screenHeight,
							screenWidth, true);
					int w = scaled.getWidth();
					int h = scaled.getHeight();
					Matrix mtx = new Matrix();
					mtx.postRotate(90);
					bm = Bitmap.createBitmap(scaled, 0, 0, w, h, mtx, true);

				} else
				{
					
					Bitmap scaled = Bitmap.createScaledBitmap(bm, CrImgXINT,
							CrImgYINT, true);
					bm = scaled;
				}


				
				
				
				double screentosurfvRatioX = ((float)screenWidth/surfaceView.getWidth());
				double screentosurfvRatioY = ((float)screenHeight/surfaceView.getHeight());
								
				Camera.Parameters params1 = camera1.getParameters();
				if(checkSamporCont == 1)
				{
					InitialExpos = bm;
//					InitialExpos = Bitmap.createBitmap(bm, (int)(cropSTARTX*screentosurfvRatioX), (int)(cropSTARTY*screentosurfvRatioY), (int)(CrImgXINT*screentosurfvRatioX), (int)(CrImgYINT*screentosurfvRatioY));
			//		savePic(InitialExpos);
					AmplifPhoto.setImageBitmap(InitialExpos);

				}

				
				
				camera1.stopPreview();


				previewing = false;
				
				AmplifPhoto.setImageBitmap(InitialExpos);
				
			}

		}

	};
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	public void restartApplication()
	{
		
		finish();
		startActivity(getIntent());
	}
	
	
	

	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
/*	
	public void thresholdProcess(float NCintensityval, float PCintensityval, float Sampleintensityval, int whichwell)
	{
//		ThresholdValue = Float.valueOf(Threshold.getText().toString());
		
		float sampleNCDif;
		float NCPCDif;
		float thresholdofNCPCDif;
		
		sampleNCDif = Math.abs(Sampleintensityval-NCintensityval);
		NCPCDif = Math.abs(PCintensityval-NCintensityval);
//		thresholdofNCPCDif = (NCPCDif)*(ThresholdValue/100);
		
		System.out.println("This is NC INtensity: "+NCintensityval);
		System.out.println("This is PC INtensity: "+PCintensityval);

		System.out.println("This is Sample INtensity: "+Sampleintensityval);

		ImageView tempimg = (allimageViewsCheck.get(whichwell));
		System.out.println(tempimg);

	//Checking if difference of blue intensity of sample and NC is above  THRESHOLD percent of PC and NC blue intensity			
		//CHANGE IF NEEDED
//		if(sampleNCDif>(thresholdofNCPCDif)&&Sampleintensityval<NCintensityval)
		{
			tempimg.setImageDrawable(allfilledDrawables.get(whichwell));

			passedThresholdVals.add(namesselectWells.get(whichwell));
			
			if(namesselectWells.get(whichwell).equals("HIV"))
			{
//				OtherVirus.append(namesselectWells.get(whichwell)+", ");
			}
			else
			{
//				FinalHPVResult.append(namesselectWells.get(whichwell)+", ");
			}
			
	//		FinalHPVResult.setText("Threshold Passed: "+namesselectWells.get(whichwell));
			
		}
		
		
	}
*/	

	
	

	
	
	
	
	
	
/*	
	public float getHueSubtract(Bitmap pictogetHue1, Bitmap pictogetHue2)
	{	

		
		Bitmap bmSampOrig1 = pictogetHue1;
		Bitmap bmSampOrig2 = pictogetHue2;
		
		// TODO Auto-generated method stub

		ArrayList<Integer> newImgR1 = new ArrayList<Integer>();
		ArrayList<Integer> newImgG1 = new ArrayList<Integer>();
		ArrayList<Integer> newImgB1 = new ArrayList<Integer>();
		ArrayList<Integer> totRGBIntensity1 = new ArrayList<Integer>();
		
		ArrayList<Integer> newImgR2 = new ArrayList<Integer>();
		ArrayList<Integer> newImgG2 = new ArrayList<Integer>();
		ArrayList<Integer> newImgB2 = new ArrayList<Integer>();
		ArrayList<Integer> totRGBIntensity2 = new ArrayList<Integer>();
		
		int origWidth1 = bmSampOrig1.getWidth();
		int origHeight1 = bmSampOrig1.getHeight();
		int origWidth2 = bmSampOrig2.getWidth();
		int origHeight2 = bmSampOrig2.getHeight();
		
		
		
		int RGBIntensAdder1 = 0;
		int RGBIntensAdder2 = 0;
		
		int pixelcounter1 = 0;
		int pixelcounter2 = 0;
		
		int totRed1 = 0;
		int totBlue1 = 0;
		int totGreen1 = 0;
		int totRed2 = 0;
		int totBlue2 = 0;
		int totGreen2 = 0;
		
		
		for(int x = 0; x<origWidth1; x++)
		{
			for(int y = 0; y<origHeight1; y++)
			{
				int redpicRes1 = Color.red(bmSampOrig1.getPixel(x, y));			
				int greenpicRes1 = Color.green(bmSampOrig1.getPixel(x, y));
				int bluepicRes1 = Color.blue(bmSampOrig1.getPixel(x, y));
				totRed1+=redpicRes1;
				totBlue1+=bluepicRes1;
				totGreen1+=greenpicRes1;			
				pixelcounter1+=1;
				int totRGBinstance1 = redpicRes1+greenpicRes1+bluepicRes1;
				RGBIntensAdder1 += totRGBinstance1;
			}
		}
		
		for(int x = 0; x<origWidth2; x++)
		{
			for(int y = 0; y<origHeight2; y++)
			{
				int redpicRes2 = Color.red(bmSampOrig2.getPixel(x, y));			
				int greenpicRes2 = Color.green(bmSampOrig2.getPixel(x, y));
				int bluepicRes2 = Color.blue(bmSampOrig2.getPixel(x, y));
				totRed2+=redpicRes2;
				totBlue2+=bluepicRes2;
				totGreen2+=greenpicRes2;			
				pixelcounter2+=1;
				int totRGBinstance2 = redpicRes2+greenpicRes2+bluepicRes2;
				RGBIntensAdder2 += totRGBinstance2;
			}
		}		
		
		float[] hsv1 = new float[3];
		Color.RGBToHSV(totRed1-totRed2, totGreen1-totGreen2, totBlue1-totBlue2, hsv1);
		
		float HueDif = hsv1[0];
			
		return HueDif;

	}
	
	
	
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height)
	{

	}

	@Override
	public void surfaceCreated(SurfaceHolder holder)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder)
	{
		// TODO Auto-generated method stub

	}


	@Override
	public boolean onTouch(View v, MotionEvent event)
	{
		
		if(ScreenTouchReason==1)
		{
			System.out.println("RadioB ID:  "+XYbluerectRadG.getCheckedRadioButtonId());

	        // Getting the X-Coordinate of the touched position
	//        float Xtouch = (event.getX())*(event.getXPrecision());
			float Xtouch = event.getX();
	        System.out.println(event.getX());
	        System.out.println(event.getXPrecision());
	 
	        // Getting the Y-Coordinate of the touched position
	//        float Ytouch = (event.getY())*(event.getYPrecision());
	        float Ytouch = (event.getY());
	        
	        int Xinttouch = Math.round(Xtouch);
	        int Yinttouch = Math.round(Ytouch);
	        
	        
			System.out.println("X value of surfaceView " +surfaceView.getWidth());
			System.out.println("Y value of surfaceView " +surfaceView.getHeight());

	        System.out.println(XYbluerectRadG.getCheckedRadioButtonId());
	        
	        if(XYbluerectRadG.getCheckedRadioButtonId()==XY1Radio.getId())
	        {
	        	bluerectX = Xinttouch;
		        bluerectY = Yinttouch;
		        
		        pctouchcheck = 1;
				CropRectX.setText(String.valueOf(bluerectX));
				CropRectY.setText(String.valueOf(bluerectY));
				checkifbothXYpointsset+=1;
				drawPoint();
	        }
	        

	        if(XYbluerectRadG.getCheckedRadioButtonId()==XY2Radio.getId())
	        {
	        	bluerectX2 = Xinttouch;
		        bluerectY2 = Yinttouch;
		        
		        nctouchcheck = 1;
				CropRectX2.setText(String.valueOf(bluerectX2));
				CropRectY2.setText(String.valueOf(bluerectY2));
				checkifbothXYpointsset+=1;
				drawPoint();
	        }
		}
		
		if(ScreenTouchReason==0)
		{
			
			if (camera1 != null)
			{
				
					Camera.Parameters params = camera1.getParameters();

				    ArrayList<Camera.Area> focusAreas = new ArrayList<Camera.Area>();
				    focusAreas.add(new Camera.Area(focusArea, 1000));

				    params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
				    params.setFocusAreas(focusAreas);

					camera1.setParameters(params);

		        	System.out.println("AutoFocus is STARTING");
		        	try
					{
		        		camera1.cancelAutoFocus();
						camera1.startPreview();
						camera1.autoFocus(new Camera.AutoFocusCallback()
						{
		                    @Override
		                    public void onAutoFocus(boolean success, Camera camera)
		                    {

		                            Parameters parameters = camera.getParameters();
		                            parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_MACRO);
		                            if (parameters.getMaxNumFocusAreas() > 0)
		                            {
		                                parameters.setFocusAreas(null);
		                            }
		                            System.out.println("ExposLock_FocusTouch1: "+parameters.getAutoExposureLock());
		                            parameters.setAutoExposureLock(true);
		                            parameters.setAutoWhiteBalanceLock(true);
		                            Exposcompensation = parameters.getExposureCompensation();
		                            System.out.println("ExposLock_FocusTouch2: "+parameters.getAutoExposureLock());
		                            
//		                            System.out.println(parameters.flatten());
		                            camera.setParameters(parameters);
		                            
		                            camera.startPreview();
		                        
		                    }
						});
						
					}
		        	catch (Exception e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        	
			}

		}

		
		return false;
	}
}
